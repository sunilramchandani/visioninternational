<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PageStep extends Model
{
    protected $table = 'steps'; 
    protected $primaryKey = 'id';
    
}
