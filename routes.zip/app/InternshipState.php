<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InternshipState extends Model
{
    //
}
