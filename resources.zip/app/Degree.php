<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Degree extends Model
{
    protected $table = 'degree'; 
    protected $primaryKey = 'degree_id';
}
