<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Major extends Model
{
    protected $table = 'major'; 
    protected $primaryKey = 'major_id';
}
