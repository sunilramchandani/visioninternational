{{ $title }}
{{ $author }}
{!! $body !!}