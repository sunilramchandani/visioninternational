<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InternshipDuration extends Model
{
    protected $table = 'internship_duration'; 
    protected $primaryKey = 'id';
    public $timestamps = false;

}
